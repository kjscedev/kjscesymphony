<!-- SVG EFFECT -->
<svg class="shape-overlays" viewBox="0 0 100 100" preserveAspectRatio="none">
    <defs>
        <linearGradient id="gradient1" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="yellow" />
            <stop offset="100%" stop-color="orange" />
        </linearGradient>
        <linearGradient id="gradient2" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#ff6666" />
            <stop offset="100%" stop-color="#e6004c" />
        </linearGradient>
        <linearGradient id="gradient3" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#F80C3A" />
            <stop offset="100%" stop-color="#9F4676" />
        </linearGradient>
    </defs>
    <path class="shape-overlays__path"></path>
    <path class="shape-overlays__path"></path>
    <path class="shape-overlays__path"></path>
</svg>
