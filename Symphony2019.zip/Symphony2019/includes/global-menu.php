
            <div class="global-menu ">

                <div class="menu-wrap global-menu__item global-menu__item--demo-6">
                    <div class="hamburger-menu">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hamburger-img global-menu__item global-menu__item--demo-6"><img src="assets/images/monster.svg" alt=""></div>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="global-menu__wrap">
                                        <a class="global-menu__item global-menu__item--demo-6" href="about-us.html">About</a>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="global-menu__wrap">
                                        <a class="global-menu__item global-menu__item--demo-6" href="theme.html">Theme</a>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="global-menu__wrap">
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>

                                            </div>
                                            <div class="col-md-6">
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="global-menu__wrap">
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">pro-shows</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="global-menu__wrap">
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">Shield</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="global-menu__wrap">
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">Syhahi</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                        <a class="global-menu__item global-menu__item--demo-6" href="#">events</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6"><img src="assets/images/Symphony-circle.svg" alt="" class="img-responsive" width="100px" height="100px">
                                    <a href="">
                                        <p>QUESTIONS? <a href="">reach us</a></p>
                                    </a>
                                </div>

                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="global-menu__wrap">
                                                <a class="global-menu__item global-menu__item--demo-6" href="rules.html">Rules</a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="global-menu__wrap">
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">Parvaah</a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="global-menu__wrap">
                                                <a class="global-menu__item global-menu__item--demo-6" href="#">REachus</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="socialmedia">
                            <div class="socialmedia__line1">
                                <img src="assets/images/2019/social media icons/facebook.svg" alt="" />
                                <img src="assets/images/2019/social media icons/youtube.svg" alt="" />
                                <img src="assets/images/2019/social media icons/instagram.svg" alt="" />
                            </div>
                            <div class="socialmedia__line2">
                                <img src="assets/images/2019/social media icons/twitter.svg" alt="" />
                                <img src="assets/images/2019/social media icons/snapchat.svg" alt="" />
                                <img src="assets/images/2019/social media icons/wordpress.svg" alt="" />
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>